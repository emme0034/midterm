var app = angular.module('myApp', []); 

app.controller('todo', function($scope) {

    $scope.tasks = [];
    
    $scope.saved = JSON.parse(localStorage.getItem('tasksItems'));
    $scope.tasks = Array.isArray($scope.saved) ? $scope.saved : [];
    console.log($scope.tasks)
    
    $scope.createTask = {description:'', dueDate:'', doneTask: false};
    
   
    $scope.addTask = function() {
        $scope.createTask.id = cuid()
        
        $scope.createTask.doneTask = false;
        
        $scope.tasks.push($scope.createTask)
        
        $scope.createTask = {description:'', dueDate:'', doneTask: false}

        localStorage.setItem('tasksItems', JSON.stringify($scope.tasks));
    };

    
    $scope.deleteTask = function(task){

        const index = $scope.tasks.findIndex(item => item.id === task.id);
        $scope.tasks.splice(this.$index, 1)
        
        localStorage.setItem('tasksItems', JSON.stringify($scope.tasks));

    };
    
 
    $scope.save = function () {
        localStorage.setItem('tasksItems', JSON.stringify($scope.tasks));
    }
    
});